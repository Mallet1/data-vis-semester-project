# Chicago Crime Data Visualization

Data visualization project analyzing Chicago crime patterns.

**Data**: https://data.cityofchicago.org/Public-Safety/Crimes-2001-to-Present/ijzp-q8t2/about_data  
**Part 1**: Data exploration and analysis

See `instructions.md` for setup and `report_part1.md` for Part 1 report.

